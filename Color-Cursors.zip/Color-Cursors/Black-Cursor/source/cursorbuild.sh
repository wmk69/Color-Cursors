#!/bin/sh

if test ! -d cursors;
then mkdir cursors
fi

####################################################################################################
#####     BUILD CURSORS     ########################################################################

xcursorgen arrow.conf			cursors/arrow
xcursorgen ask.conf			cursors/ask
xcursorgen cell.conf			cursors/cell
xcursorgen col-resize.conf		cursors/col-resize
xcursorgen context-menu.conf		cursors/context-menu
xcursorgen copy.conf			cursors/copy
xcursorgen cross.conf			cursors/cross
xcursorgen ew-resize.conf		cursors/ew-resize
xcursorgen fleur.conf			cursors/fleur
xcursorgen forbidden.conf		cursors/forbidden
xcursorgen link.conf			cursors/link
xcursorgen move.conf			cursors/move
xcursorgen nesw-resize.conf		cursors/nesw-resize
xcursorgen ns-resize.conf		cursors/ns-resize
xcursorgen nwse-resize.conf		cursors/nwse-resize
xcursorgen progress.conf		cursors/progress
xcursorgen right-arrow.conf		cursors/right-arrow
xcursorgen row-resize.conf		cursors/row-resize
xcursorgen text.conf			cursors/text
xcursorgen up-arrow.conf		cursors/up-arrow
xcursorgen vertical-text.conf		cursors/vertical-text
xcursorgen watch.conf			cursors/watch
xcursorgen x-cursor.conf		cursors/x-cursor
xcursorgen zoom-in.conf			cursors/zoom-in
xcursorgen zoom-out.conf		cursors/zoom-out

####################################################################################################
#####     CREATE COPIES     ########################################################################

cd cursors

cp arrow		basic-arrow
cp arrow		basic_arrow
cp arrow		default
cp arrow		left_ptr
cp arrow		top-left-arrow
cp arrow		top_left_arrow

cp ask			dnd-ask
cp ask			help
cp ask			question_arrow
cp ask			whats_this

cp cell			plus

cp col-resize		split_v

cp copy			dnd-copy

cp cross		crosshair
cp cross		cross_reverse
cp cross		diamond_cross
cp cross		tcross

cp ew-resize		h_double_arrow
cp ew-resize		size_hor
cp ew-resize		left
cp ew-resize		left_side
cp ew-resize		right
cp ew-resize		right_side
cp ew-resize		sb_h_double_arrow
cp ew-resize		e-resize
cp ew-resize		w-resize

cp fleur		all-scroll
cp fleur		size_all

cp forbidden		circle
cp forbidden		crossed_circle
cp forbidden		dnd-none
cp forbidden		no-drop
cp forbidden		not-allowed
cp forbidden		pirate

cp link			alias
cp link			dnd-link
cp link			hand1
cp link			hand2
cp link			left-hand
cp link			pointer
cp link			pointing_hand

cp move			dnd-move
cp move			grabbing

cp nesw-resize		top_right_corner
cp nesw-resize		ur_angle
cp nesw-resize		bd_double_arrow
cp nesw-resize		size_bdiag
cp nesw-resize		bottom_left_corner
cp nesw-resize		ll_angle
cp nesw-resize		ne-resize
cp nesw-resize		sw-resize

cp ns-resize		based-up
cp ns-resize		based_arrow_up
cp ns-resize		up
cp ns-resize		top_side
cp ns-resize		double-arrow
cp ns-resize		double_arrow
cp ns-resize		size_ver
cp ns-resize		v_double_arrow
cp ns-resize		based-down
cp ns-resize		based_arrow_down
cp ns-resize		bottom_side
cp ns-resize		down
cp ns-resize		sb_v_double_arrow
cp ns-resize		n-resize
cp ns-resize		s-resize

cp nwse-resize		top_left_corner
cp nwse-resize		ul_angle
cp nwse-resize		fd_double_arrow
cp nwse-resize		size_fdiag
cp nwse-resize		bottom_right_corner
cp nwse-resize		lr_angle
cp nwse-resize		nw-resize
cp nwse-resize		se-resize

cp progress		left_ptr_watch

cp right-arrow		draft_large
cp right-arrow		draft_small
cp right-arrow		right_ptr
cp right-arrow		top-right-arrow

cp row-resize		split_h

cp text			ibeam
cp text			xterm

cp up-arrow		color-picker
cp up-arrow		center_ptr
cp up-arrow		up_arrow
cp up-arrow		sb_up_arrow

cp watch		wait

cp x-cursor		X_cursor

####################################################################################################
#####     CREATE SYMBOLIC LINKS (HASHES)     #######################################################

cp -s col-resize 	14fef782d02440884392942c11205230
cp -s row-resize	2870a09082c103050810ffdffffe0204

cp -s nwse-resize	c7088f0f3e6c8088236ef8e1e3e70000
cp -s nesw-resize	fcf1c3c7cd4491d801f1e1c78f100000
cp -s ns-resize		00008160000006810000408080010102
cp -s ew-resize		028006030e0e7ebffc7f7070c0600140

cp -s pointer		e29285e634086352946a0e7090d73106
cp -s move		4498f0e0c1937ffe01fd06f973665830

cp -s alias		640fb0e74195791501fd1ed57b41487f
cp -s copy		6407b0e94181790501fd1e167b474872

cp -s no-drop		03b6e0fcb3499374a867c041f52298f0
cp -s help		d9ce0ab605698f320427677b458ad60b
cp -s wait		0426c94ea35c87780ff01dc239897213
cp -s progress		9116a3ea924ed2162ecab71ba103b17f

cp -s all-scroll	9d800788f1b08800ae810202380a0822 # hand1, not seen by now
cp -s progress		3ecb610c1bf2410f44200f48c40d3599 # left_ptr_watch, not seen by now
cp -s copy		1081e37283d90000800003c07f3ef6bf # copy, not seen by now
cp -s alias		3085a0e285430894940527032f8b26df # link, not seen by now
cp -s move		9081237383d90e509aa00f00170e968f # move, not seen by now

# the Mozilla cursor hashes

cp -s progress		08e8e1c95fe2fc01f976f1e063a24ccd # moz-spinning
cp -s help		5c6cd98b3f3ebcb1f9c7f1c204630408 # mozilla's question_arrow
cp -s all-scroll	5aca4d189052212118709018842178c0 # moz-grab
cp -s grabbing		208530c400c041818281048008011002 # moz-grabbing
cp -s zoom-in		f41c0e382c94c0958e07017e42b00462 # moz-zoom-in
cp -s zoom-out		f41c0e382c97c0938e07017e42800402 # moz-zoom-out
cp -s copy		08ffe1cb5fe6fc01f906f1c063814ccf # moz-copy
cp -s alias		0876e1c15ff2fc01f906f1c363074c0f # moz-alias
cp -s context-menu	08ffe1e65f80fcfdf9fff11263e74c48 # moz-context-menu

# Mozilla cursor hashes for CSS3 cursor property

cp -s no-drop		03b6e0fcb3499374a867d041f52298f0 # no-drop/not-allowed
cp -s vertical-text	048008013003cff3c00c801001200000 # vertical-text
cp -s col-resize	043a9f68147c53184671403ffa811cc5 # col-resize
cp -s row-resize	c07385c7190e701020ff7ffffd08103c # row-resize
cp -s nesw-resize	50585d75b494802d0151028115016902 # nesw-resize
cp -s nwse-resize	38c5dff7c7b8962045400281044508d2 # nwse-resize

####################################################################################################
#####     DONE!     ################################################################################

echo "Done! Created ./cursors directory. Move it into ~/.icons/default to install."

####################################################################################################
#####     END SCRIPT     ###########################################################################
####################################################################################################

